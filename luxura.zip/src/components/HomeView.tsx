import React, { useState, useEffect } from 'react';
import { ActivePage } from '../types';
import { BRANDS, VEHICLES } from '../data';
import { Search, Calendar, ChevronRight, Award, BadgeAlert, Sparkles, Shield, Compass, TrendingUp, Heart, Star, ArrowRight, Play, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CardStack } from './CardStack';
import CardSwap, { Card } from './CardSwap';
import CircularTestimonials from './CircularTestimonials';
import ZoomParallax from './ZoomParallax';
import FlowingMenu from './FlowingMenu';
import LogoCarousel, {
  MercedesIcon,
  BMWIcon,
  AudiIcon,
  PorscheIcon,
  ToyotaIcon,
  HyundaiIcon,
  TeslaIcon,
  TataIcon,
  LandRoverIcon,
  LamborghiniIcon,
  MahindraIcon,
  SuzukiIcon,
} from './LogoCarousel';

const brandLogos = [
  { name: 'Mercedes-Benz', id: 1, img: MercedesIcon },
  { name: 'BMW', id: 2, img: BMWIcon },
  { name: 'Audi', id: 3, img: AudiIcon },
  { name: 'Porsche', id: 4, img: PorscheIcon },
  { name: 'Toyota', id: 5, img: ToyotaIcon },
  { name: 'Hyundai', id: 6, img: HyundaiIcon },
  { name: 'Tesla', id: 7, img: TeslaIcon },
  { name: 'Tata Motors', id: 8, img: TataIcon },
  { name: 'Land Rover', id: 9, img: LandRoverIcon },
  { name: 'Lamborghini', id: 10, img: LamborghiniIcon },
  { name: 'Mahindra', id: 11, img: MahindraIcon },
  { name: 'Maruti Suzuki', id: 12, img: SuzukiIcon },
];

const userTestimonials = [
  {
    quote: "Every luxury detail feels incredibly curated. The interface response, quiet cabin, and powerful acceleration turn daily city commuting into a highly meditative and relaxing journey.",
    name: "David Lee",
    designation: "Architect & Design Principal",
    src: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=800&auto=format&fit=crop"
  },
  {
    quote: "Every drive feels effortless. The transition is smooth, quiet, and powerful — it's like the car understands me before I even move. The responsiveness and control give me confidence on every road.",
    name: "Maria Gonzalez",
    designation: "Urban Commuter & Tech Executive",
    src: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=800&auto=format&fit=crop"
  },
  {
    quote: "The corporate membership privileges are unmatched. Elite customer care, expedited finance approvals, and pristine vehicle servicing make managing my electric fleet absolutely seamless.",
    name: "Sarah Jenkins",
    designation: "Design Consultant",
    src: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=800&auto=format&fit=crop"
  }
];

const HERO_SLIDES = [
  {
    id: 'luxura-gtr',
    brand: 'Porsche',
    model: '911 Carrera GTS',
    watermark: '911 GTS',
    title: 'Engineering Pure Emotion',
    desc: 'An icon that stays ahead of its time. Experience razor-sharp feedback, flat-6 twin-turbo power, and timeless design.',
    image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&q=85&w=2400',
    thumbnail: 'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&q=80&w=200',
    carCutout: 'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&q=80&w=1200',
    ctaLabel: 'Explore Porsche 911',
    type: 'High-Performance Sports Car',
    targetId: 'featured-elite-fleet'
  },
  {
    id: 'luxura-executive',
    brand: 'Mercedes-Benz',
    model: 'E-Class Executive',
    watermark: 'E-CLASS',
    title: 'The Ultimate Drive, Redefined',
    desc: 'The epitome of executive prestige. Unparalleled ride quality through adaptive air suspension, active assistance, and custom Chauffeur comfort.',
    image: 'https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?auto=format&fit=crop&q=85&w=2400',
    thumbnail: 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&q=80&w=200',
    carCutout: 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&q=80&w=1200',
    ctaLabel: 'Experience E-Class',
    type: 'Executive Luxury Sedan',
    targetId: 'featured-elite-fleet'
  },
  {
    id: 'hyundai-ioniq-5',
    brand: 'Hyundai',
    model: 'Ioniq 5',
    watermark: 'IONIQ 5',
    title: 'The Future of Electric Luxury',
    desc: 'Retro-futuristic styling meets breathtaking 800V ultra-fast charging capabilities. Step into a sustainable, lounge-like cabin.',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=85&w=2400',
    thumbnail: 'https://images.unsplash.com/photo-1554744512-d6c603f27c54?auto=format&fit=crop&q=80&w=200',
    carCutout: 'https://images.unsplash.com/photo-1554744512-d6c603f27c54?auto=format&fit=crop&q=80&w=1200',
    ctaLabel: 'Explore Ioniq 5',
    type: 'Premium EV SUV',
    targetId: 'featured-elite-fleet'
  }
];

interface HomeViewProps {
  setActivePage: (page: ActivePage) => void;
  setSearchFilters: (filters: {
    brand: string;
    budget: string;
    fuel: string;
    transmission: string;
  }) => void;
  favorites: string[];
  toggleFavorite: (id: string) => void;
  onSelectVehicle: (id: string) => void;
}

export default function HomeView({ setActivePage, setSearchFilters, favorites, toggleFavorite, onSelectVehicle }: HomeViewProps) {
  // Card stack responsive sizing
  const [dimensions, setDimensions] = useState({ width: 520, height: 320 });

  useEffect(() => {
    const handleResize = () => {
      const w = window.innerWidth;
      if (w < 640) {
        setDimensions({ width: Math.min(340, w - 32), height: 300 });
      } else if (w < 1024) {
        setDimensions({ width: 440, height: 310 });
      } else {
        setDimensions({ width: 520, height: 320 });
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Premium Hero States
  const [activeSlide, setActiveSlide] = useState(0);
  const [isWatchExperienceOpen, setIsWatchExperienceOpen] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSlide(prev => (prev === HERO_SLIDES.length - 1 ? 0 : prev + 1));
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  const handlePrevSlide = () => {
    setActiveSlide(prev => (prev === 0 ? HERO_SLIDES.length - 1 : prev - 1));
  };

  const handleNextSlide = () => {
    setActiveSlide(prev => (prev === HERO_SLIDES.length - 1 ? 0 : prev + 1));
  };

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleMouseMove = (e: React.MouseEvent) => {
    const { clientX, clientY, currentTarget } = e;
    const { width, height, left, top } = currentTarget.getBoundingClientRect();
    const x = (clientX - left - width / 2) / (width / 2);
    const y = (clientY - top - height / 2) / (height / 2);
    setMousePosition({ x, y });
  };

  const handleMouseLeave = () => {
    setMousePosition({ x: 0, y: 0 });
  };



  const handleLifestyleClick = (lifestyle: 'SUV' | 'Sedan' | 'Electric' | 'Luxury' | 'CNG') => {
    // Apply a specialized lifestyle filter directly
    setSearchFilters({
      brand: 'All',
      budget: 'Any Budget',
      fuel: lifestyle === 'Electric' ? 'Electric' : lifestyle === 'CNG' ? 'CNG' : 'All',
      transmission: 'All'
    });
    setActivePage('inventory');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const lifestyleItems = [
    { text: 'SUV', image: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&q=80&w=800', onClick: () => handleLifestyleClick('SUV') },
    { text: 'Electric', image: 'https://images.unsplash.com/photo-1554744512-d6c603f27c54?auto=format&fit=crop&q=80&w=800', onClick: () => handleLifestyleClick('Electric') },
    { text: 'Sedan', image: 'https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&q=80&w=800', onClick: () => handleLifestyleClick('Sedan') },
    { text: 'Luxury', image: 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&q=80&w=800', onClick: () => handleLifestyleClick('Luxury') },
    { text: 'CNG', image: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&q=80&w=800', onClick: () => handleLifestyleClick('CNG') }
  ];

  return (
    <div className="bg-[#FAFAF9] text-stone-900 overflow-hidden font-sans" id="home-view">
      {/* Cinematic Watch Experience Lightbox */}
      <AnimatePresence>
        {isWatchExperienceOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-2xl"
            onClick={() => setIsWatchExperienceOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 350 }}
              className="relative w-full max-w-5xl aspect-video bg-stone-950 rounded-2xl border border-white/10 overflow-hidden shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setIsWatchExperienceOpen(false)}
                className="absolute top-4 right-4 z-10 p-2.5 bg-black/60 hover:bg-black text-white hover:text-amber-500 rounded-full transition-colors backdrop-blur-md border border-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
              <iframe
                src="https://www.youtube.com/embed/fVbVvYOfX6U?autoplay=1&mute=1&loop=1&playlist=fVbVvYOfX6U&controls=1&showinfo=0&rel=0"
                title="Mercedes AMG GT Experience"
                allow="autoplay; encrypted-media; picture-in-picture"
                allowFullScreen
                className="w-full h-full border-0"
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Premium Apple / Porsche / Awwwards Style Hero Section */}
      <section 
        className="-mt-16 sm:-mt-20 pt-16 sm:pt-20 min-h-[20dvh]  w-full relative flex flex-col justify-between overflow-hidden bg-stone-950 text-white"
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
      >
        {/* Continuous photographic background filling edge-to-edge */}
        <div className="absolute inset-0 z-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSlide}
              initial={{ opacity: 0, scale: 1.04 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
              className="absolute inset-0"
            >
              <img
                src={HERO_SLIDES[activeSlide].image}
                alt="Luxury Car Background"
                className="w-full h-full object-cover filter brightness-[0.4] contrast-[1.05] saturate-[0.95]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-transparent to-stone-950/30" />
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Oversized Type Layer (Watermark) */}
        <div className="absolute inset-x-0 top-[28%] md:top-[30%] z-10 select-none pointer-events-none text-center overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.h1
              key={activeSlide}
              initial={{ opacity: 0, scale: 1.15, y: 30 }}
              animate={{ opacity: 0.12, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: -25 }}
              transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
              className="text-[16vw] sm:text-[14vw] lg:text-[12vw] font-black tracking-[0.2em] text-white leading-none font-sans uppercase"
            >
              {HERO_SLIDES[activeSlide].watermark}
            </motion.h1>
          </AnimatePresence>
        </div>

        {/* Main Content Layout Container */}
        <div className="max-w-[1500px] w-full mx-auto px-6 sm:px-10 lg:px-16 flex-grow flex flex-col justify-between relative z-20">
          
          {/* Spacer to slide content nicely below top sticky navigation */}
          <div className="h-4 sm:h-24" />

          {/* Built Subject Showcase (Overlaps watermark text visually) */}
          <div className="flex-grow flex items-center justify-center py-2 sm:py-6 md:py-10 z-20 relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeSlide}
                initial={{ opacity: 0, scale: 0.95, y: 40 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 1.05, y: -30 }}
                transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
                className="relative w-full max-w-[340px] sm:max-w-[480px] md:max-w-[700px] lg:max-w-[900px] aspect-[16/9] md:aspect-[21/9] rounded-2xl md:rounded-3xl overflow-hidden border border-white/10 shadow-[0_32px_80px_rgba(0,0,0,0.65)] bg-stone-900/30 backdrop-blur-md group"
              >
                <img
                  src={HERO_SLIDES[activeSlide].carCutout}
                  alt={HERO_SLIDES[activeSlide].model}
                  className="w-full h-full object-cover scale-102 group-hover:scale-106 transition-transform duration-[1.5s] ease-[0.16,1,0.3,1]"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-stone-950/20 z-10 pointer-events-none" />
                
                {/* Interactive Floating Watch Experience Button */}
                <div className="absolute inset-0 flex items-center justify-center z-20">
                  <button
                    onClick={() => setIsWatchExperienceOpen(true)}
                    className="p-4 sm:p-5 rounded-full bg-white/10 hover:bg-white text-white hover:text-stone-950 border border-white/20 hover:border-white transition-all duration-300 shadow-lg pointer-events-auto cursor-pointer group/btn active:scale-95"
                    title="Watch Experience Trailer"
                  >
                    <Play size={20} fill="currentColor" className="translate-x-0.5 group-hover/btn:scale-110 transition-transform" />
                  </button>
                </div>

                {/* Elegant overlay badge */}
                <div className="absolute bottom-4 left-6 md:bottom-6 md:left-8 z-20 text-left">
                  <span className="text-[9px] font-mono font-bold tracking-widest uppercase bg-amber-600 px-2.5 py-0.5 rounded text-stone-950 mb-2 inline-block shadow-xs">
                    {HERO_SLIDES[activeSlide].brand}
                  </span>
                  <h3 className="text-lg md:text-xl font-bold tracking-tight text-white mb-0.5">
                    {HERO_SLIDES[activeSlide].model}
                  </h3>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Bottom Controls and Story Info Layout (Grid format) */}
          <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-5 md:gap-8 items-end mt-auto z-30 pb-6 md:pb-14 pt-4">
            
            {/* Bottom-left anchor: Story Block */}
            <div className="lg:col-span-7 text-left max-w-xl">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeSlide}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.5 }}
                  className="space-y-4"
                >
                  <span className="text-[10px] font-mono font-bold tracking-widest text-amber-500 uppercase block">
                    {HERO_SLIDES[activeSlide].type}
                  </span>
                  <h2 className="text-2xl sm:text-4xl md:text-5xl font-black tracking-tight leading-[1.1] text-white">
                    {HERO_SLIDES[activeSlide].title}
                  </h2>
                  <p className="text-stone-300 text-xs sm:text-sm md:text-base font-light leading-relaxed hidden sm:block">
                    {HERO_SLIDES[activeSlide].desc}
                  </p>
                  <div className="pt-1 md:pt-2">
                    <button
                      onClick={() => {
                        if (HERO_SLIDES[activeSlide].targetId) {
                          const el = document.getElementById(HERO_SLIDES[activeSlide].targetId);
                          if (el) el.scrollIntoView({ behavior: 'smooth' });
                        }
                      }}
                      className="group inline-flex items-center gap-2.5 bg-white hover:bg-amber-600 text-stone-950 hover:text-white px-6 py-3.5 rounded-full font-semibold text-xs uppercase tracking-wider transition-all duration-300 shadow-md cursor-pointer active:scale-98"
                    >
                      <span>{HERO_SLIDES[activeSlide].ctaLabel}</span>
                      <ArrowRight size={15} className="group-hover:translate-x-1.5 transition-transform duration-300" />
                    </button>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Bottom-right anchor: Carousel thumbnails cluster */}
            <div className="lg:col-span-5 flex items-center justify-start lg:justify-end">
              <div className="bg-black/45 backdrop-blur-md border border-white/10 px-5 py-3 rounded-full flex items-center space-x-3.5 shadow-xl">
                {/* Previous Button */}
                <button
                  onClick={handlePrevSlide}
                  className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center text-white hover:bg-white hover:text-stone-950 transition-all duration-300 cursor-pointer active:scale-90"
                  title="Previous Slide"
                >
                  <ChevronRight size={15} className="rotate-180" />
                </button>

                {/* Thumbnails row */}
                <div className="flex items-center space-x-2">
                  {HERO_SLIDES.map((slide, idx) => (
                    <button
                      key={slide.id}
                      onClick={() => setActiveSlide(idx)}
                      className={`relative w-12 h-8 rounded-lg overflow-hidden transition-all duration-300 cursor-pointer ${
                        activeSlide === idx
                          ? 'ring-2 ring-amber-500 scale-110 shadow-lg'
                          : 'opacity-50 hover:opacity-85'
                      }`}
                    >
                      <img
                        src={slide.thumbnail}
                        alt="Preview thumbnail"
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </button>
                  ))}
                </div>

                {/* Next Button */}
                <button
                  onClick={handleNextSlide}
                  className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center text-white hover:bg-white hover:text-stone-950 transition-all duration-300 cursor-pointer active:scale-90"
                  title="Next Slide"
                >
                  <ChevronRight size={15} />
                </button>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Trust & Stats Bar */}
      <section className="bg-stone-100/80 border-y border-stone-200/80 py-8 px-4" id="stats-bar">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div className="flex flex-col items-center space-y-1">
            <span className="text-3xl font-extrabold text-amber-700 tracking-tight">500+</span>
            <span className="text-xs text-stone-500 uppercase tracking-widest font-medium">Premium Handpicked Cars</span>
          </div>
          <div className="flex flex-col items-center space-y-1 border-y md:border-y-0 md:border-x border-stone-200 py-4 md:py-0">
            <span className="text-3xl font-extrabold text-stone-900 tracking-tight">₹14.49L - ₹1.84Cr</span>
            <span className="text-xs text-amber-700 uppercase tracking-widest font-medium">Accessible Luxury range</span>
          </div>
          <div className="flex flex-col items-center space-y-1">
            <span className="text-3xl font-extrabold text-amber-700 tracking-tight flex items-center justify-center space-x-1">
              <span>4.9/5</span>
              <Star className="w-6 h-6 text-amber-600 fill-current shrink-0" />
            </span>
            <span className="text-xs text-stone-500 uppercase tracking-widest font-medium">Elite Customer Satisfaction</span>
          </div>
        </div>
      </section>



      {/* Multiple Premium Brands Available Section with LogoCarousel */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28" id="brands-available-grid">
        <div className="text-center mb-10 md:mb-14">
          <span className="text-stone-500 font-mono text-[10px] uppercase tracking-widest font-semibold">Multiple Premium Brands Available</span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-stone-900 mt-1">Our Featured Elite Automakers</h2>
          <p className="text-stone-500 text-sm mt-3 max-w-xl mx-auto font-light leading-relaxed">
            Our showroom offers select high-tier brands to match your exact performance standard and design philosophy. Click any rotating brand card to explore its dedicated fleet.
          </p>
        </div>

        <div className="flex justify-center items-center">
          <LogoCarousel
            columnCount={5}
            logos={brandLogos}
            onLogoClick={(brandName) => {
              setSearchFilters({ brand: brandName, budget: 'Any Budget', fuel: 'All', transmission: 'All' });
              setActivePage('inventory');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        </div>
      </section>

      {/* Featured Elite Fleet */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 lg:py-28" id="featured-elite-fleet">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-10 md:mb-12">
          <div>
            <span className="text-stone-600 font-mono text-[10px] sm:text-xs uppercase tracking-widest font-semibold flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-stone-500" />
              <span>Handpicked Masterpieces</span>
            </span>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-stone-900 mt-2">
              Featured Elite Fleet
            </h2>
            <p className="text-stone-500 text-xs sm:text-sm mt-2 max-w-xl font-light leading-relaxed">
              Experience our highest-curated luxury and performance machines, fully cached for real-time engagement.
            </p>
          </div>
          <button
            onClick={() => {
              setActivePage('inventory');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="text-[10px] sm:text-xs font-bold text-amber-700 hover:text-amber-600 uppercase tracking-widest mt-6 md:mt-0 flex items-center space-x-1.5 group border border-amber-600/25 px-4 py-2.5 rounded bg-amber-50 hover:bg-amber-100/60 transition-all"
          >
            <span>View All Showroom ({VEHICLES.length} Cars)</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        <div className="mt-8 sm:mt-12 mb-16 md:mb-24 flex justify-center w-full">
          <CardStack
            items={VEHICLES.map((v) => ({
              id: v.id,
              title: `${v.brand} ${v.model}`,
              description: v.description,
              imageSrc: v.images[0].includes('unsplash.com') && v.images[0].includes('w=1200')
                ? v.images[0].replace('w=1200', 'w=600')
                : v.images[0],
              vehicle: v,
            }))}
            initialIndex={0}
            autoAdvance
            intervalMs={3000}
            pauseOnHover
            showDots
            cardWidth={dimensions.width}
            cardHeight={dimensions.height}
            renderCard={(item, { active }) => {
              const vehicle = item.vehicle;
              const isFav = favorites.includes(vehicle.id);
              
              return (
                <div className="relative h-full w-full bg-stone-900 overflow-hidden text-white group/card select-none rounded-2xl">
                  {/* Background Image */}
                  <img
                    src={vehicle.images[0]}
                    alt={vehicle.model}
                    loading="eager"
                    referrerPolicy="no-referrer"
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover/card:scale-105 opacity-80"
                    draggable={false}
                  />
                  
                  {/* Subtle overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950/95 via-stone-950/45 to-stone-950/15" />

                  {/* Top Header Controls (Active Card gets full interactivity) */}
                  <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-10">
                    <span className="bg-amber-600/90 backdrop-blur-md text-white text-[10px] font-bold uppercase px-2.5 py-1 rounded tracking-wider border border-amber-500/20 shadow-lg">
                      {vehicle.type}
                    </span>
                    <button
                      type="button"
                      disabled={!active}
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite(vehicle.id);
                      }}
                      className={`p-2 bg-black/40 hover:bg-black/60 text-white backdrop-blur-md rounded-full transition-all duration-300 border border-white/10 active:scale-95 shadow-md ${!active ? 'opacity-50 cursor-default' : 'cursor-pointer'}`}
                      title={isFav ? "Remove from Garage" : "Add to Garage"}
                    >
                      <Heart className={`w-3.5 h-3.5 ${isFav ? 'text-red-500 fill-current' : 'text-stone-300'}`} />
                    </button>
                  </div>

                  {/* Bottom Content Area */}
                  <div className="absolute bottom-0 left-0 right-0 p-5 z-10 flex flex-col justify-end">
                    <div className="space-y-1">
                      {/* Brand & Rating */}
                      <div className="flex justify-between items-center text-xs text-stone-300 font-mono">
                        <span className="uppercase tracking-widest font-semibold text-[10px]">
                          {vehicle.brand}
                        </span>
                        <span className="bg-white/10 backdrop-blur-sm text-white px-2 py-0.5 rounded flex items-center space-x-1 border border-white/10 font-bold text-[10px]">
                          <Star className="w-2.5 h-2.5 text-amber-500 fill-current" />
                          <span>{vehicle.rating}</span>
                        </span>
                      </div>

                      {/* Model Name */}
                      <h3 className="text-xl font-bold tracking-tight text-white uppercase font-sans">
                        {vehicle.model}
                      </h3>

                      {/* Short Description */}
                      <p className="text-[11px] text-stone-300/95 line-clamp-2 leading-relaxed font-light font-sans">
                        {vehicle.description}
                      </p>
                    </div>

                    {/* Divider and Footer Specs/Price */}
                    <div className="border-t border-white/10 pt-3 mt-3 flex justify-between items-center">
                      <div>
                        <span className="text-stone-400 text-[9px] uppercase font-semibold block tracking-wider">Ex-Showroom Price</span>
                        <p className="text-base font-black text-amber-500">₹{vehicle.price.toFixed(2)} Lakh*</p>
                      </div>
                      <button
                        disabled={!active}
                        onClick={(e) => {
                          if (!active) return;
                          e.stopPropagation();
                          onSelectVehicle(vehicle.id);
                        }}
                        className={`px-4 py-2 rounded text-[10px] font-bold uppercase tracking-widest transition-all ${
                          active 
                            ? 'bg-amber-600 hover:bg-amber-700 text-white cursor-pointer hover:shadow-lg shadow-amber-600/20 active:scale-95' 
                            : 'bg-white/10 text-white/50 cursor-default'
                        }`}
                      >
                        View Specs
                      </button>
                    </div>
                  </div>
                </div>
              );
            }}
          />
        </div>
      </section>

      {/* Services We Provide Section */}
      <section className="bg-white pt-16 md:pt-24 lg:pt-28 pb-8 md:pb-14 relative overflow-visible" id="services-provide">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end">
            <div>
              <span className="text-stone-500 font-mono text-[10px] uppercase tracking-widest font-semibold block mb-2">SERVICES WE PROVIDE</span>
              <h2 className="text-3xl sm:text-4xl font-black text-stone-900 uppercase tracking-tight leading-none">
                Bespoke Services <br />
                <span className="bg-gradient-to-r from-amber-700 to-amber-500 bg-clip-text text-transparent">Crafted For The Elite</span>
              </h2>
            </div>
            <p className="text-stone-500 text-xs max-w-sm mt-4 md:mt-0 leading-relaxed font-light">
              Elevate your driving lifestyle. From custom interior tailored designs to track-day curations and elite doorstep delivery, we manage your luxury fleet seamlessly.
            </p>
          </div>
        </div>

        <div className="w-full pb-2">
          <ZoomParallax
            images={[
              {
                src: "https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&q=80&w=800",
                alt: "Bespoke Customization",
                title: "Bespoke Customization",
                desc: "Handcrafted interior personalization and paint curation."
              },
              {
                src: "https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&q=80&w=800",
                alt: "Instant Diagnostics",
                title: "Expert Diagnostics",
                desc: "Real-time remote telemetry & precise health checks."
              },
              {
                src: "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&q=80&w=800",
                alt: "Elite Driving Curation",
                title: "Elite Track-Day",
                desc: "High-performance racing curation & professional training."
              },
              {
                src: "https://images.unsplash.com/photo-1563720223523-491ff04651de?auto=format&fit=crop&q=80&w=800",
                alt: "Electric Charging Setup",
                title: "Eco Infrastructure",
                desc: "Seamless home & corporate fast charging installations."
              },
              {
                src: "https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?auto=format&fit=crop&q=80&w=800",
                alt: "Doorstep Flatbed Delivery",
                title: "Pristine Delivery",
                desc: "Direct-to-door enclosed flatbed transportation."
              },
              {
                src: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800",
                alt: "Private Advisory Hub",
                title: "Fleet Advisory",
                desc: "Corporate and personal luxury investment portfolio."
              },
              {
                src: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&q=80&w=800",
                alt: "Concierge Network",
                title: "24/7 VIP Concierge",
                desc: "Dedicated account managers ready on first ring."
              }
            ]}
          />
        </div>
      </section>

      {/* Customer Testimonials Section (Chery E5 Style) */}
      <section className="bg-white py-16 md:py-24 lg:py-28 border-b border-stone-200/80" id="testimonials">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <span className="text-stone-500 font-mono text-[10px] uppercase tracking-widest font-semibold">TESTIMONIALS</span>
            <h2 className="text-3xl sm:text-4xl font-black text-stone-900 uppercase tracking-tight mt-1">What Our Customers Say</h2>
            <p className="text-stone-500 text-sm mt-1 max-w-xl mx-auto font-light">
              Read real stories from our elite owners who experienced the transition into the next era of high-end automotive engineering.
            </p>
          </div>

          <div className="flex justify-center items-center">
            <CircularTestimonials
              testimonials={userTestimonials}
              autoplay={true}
              colors={{
                name: "#1c1917",
                designation: "#b45309",
                testimony: "#44403c",
                arrowBackground: "#1c1917",
                arrowForeground: "#fafaf9",
                arrowHoverBackground: "#b45309",
              }}
              fontSizes={{
                name: "1.5rem",
                designation: "0.875rem",
                quote: "1rem",
              }}
            />
          </div>
        </div>
      </section>

      {/* Discover by Lifestyle Section with FlowingMenu */}
      <section className="py-16 md:py-24 lg:py-28 overflow-visible bg-white border-y border-stone-100" id="discover-lifestyle">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-10 md:mb-16">
          <div className="text-center space-y-3">
            <span className="text-amber-700 font-mono text-xs uppercase tracking-widest font-semibold flex items-center justify-center space-x-2">
              <TrendingUp className="w-4 h-4 text-amber-700" />
              <span>Showroom Collections</span>
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-stone-900 uppercase font-sans">
              Discover by Lifestyle
            </h2>
            <p className="text-stone-500 text-xs sm:text-sm font-light leading-relaxed max-w-2xl mx-auto">
              Hover over each collection to preview. Click any lifestyle category to view premium matching vehicles in our curated fleet.
            </p>
          </div>
        </div>

        <div className="relative w-full h-[550px] overflow-hidden">
          <FlowingMenu 
            items={lifestyleItems}
            speed={15}
            textColor="#1c1917"
            bgColor="#ffffff"
            marqueeBgColor="#b45309"
            marqueeTextColor="#ffffff"
            borderColor="rgba(120, 113, 108, 0.15)"
          />
        </div>
      </section>

      {/* Custom Festive Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 lg:py-28" id="festive-offer-banner">
        <div className="bg-gradient-to-r from-stone-50/50 via-stone-100/80 to-stone-50/50 border border-stone-200/50 rounded-2xl p-6 sm:p-12 text-center md:text-left relative overflow-hidden flex flex-col md:flex-row justify-between items-center gap-8 shadow-md">
          <div className="absolute top-0 right-0 w-96 h-96 bg-stone-400/5 rounded-full blur-3xl" />
          
          <div className="space-y-4 max-w-xl">
            <span className="inline-block px-3 py-1 bg-stone-100 text-stone-700 text-xs font-semibold tracking-wider uppercase rounded-full border border-stone-200">
              Showroom Exclusive Privileges
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-stone-900 leading-tight">
              Celebrate with <span className="text-stone-800">Luxury Privileges</span>
            </h2>
            <p className="text-sm text-stone-600 leading-relaxed font-light">
              Get corporate elite benefits up to ₹1.5 Lakh, 0% upgrade assistance, and complimentary vehicle maintenance plans for 3 years. Limited time only.
            </p>
          </div>

          <div className="shrink-0 flex flex-col items-center sm:items-start gap-4">
            <button
              onClick={() => {
                setActivePage('offers');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-8 py-3.5 bg-stone-900 hover:bg-stone-850 text-white font-bold text-xs tracking-wider uppercase rounded-md shadow-lg shadow-stone-950/20 transition-all flex items-center space-x-2"
              id="home-btn-view-offers"
            >
              <span>Explore Privileges</span>
              <ChevronRight className="w-4 h-4" />
            </button>
            <span className="text-[11px] text-stone-500 font-mono">Offer ends in: 12 Days, 05 Hours</span>
          </div>
        </div>
      </section>
    </div>
  );
}
