import React from 'react';
import { ActivePage } from '../types';
import { Mail, Phone, MapPin, ArrowUpRight, ShieldCheck, HeartHandshake, Eye, Star } from 'lucide-react';

interface FooterProps {
  setActivePage: (page: ActivePage) => void;
}

export default function Footer({ setActivePage }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-stone-50 text-stone-500 border-t border-stone-200/80 pt-16 pb-8 font-sans" id="app-footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <span className="text-xl font-bold tracking-widest text-stone-900">
                LUXURA
              </span>
              <span className="text-xs font-light tracking-wider text-stone-400 border-l border-stone-300 pl-2">
                MOTORS
              </span>
            </div>
            <p className="text-sm leading-relaxed text-stone-500">
              Lucknow's premier showroom sanctuary for elite performance, sustainable luxury, and bespoke automobile experiences. Excellence in every handpicked detail.
            </p>
            <div className="flex space-x-4 pt-2">
              {['Instagram', 'Twitter', 'LinkedIn', 'YouTube'].map((social) => (
                <a
                  key={social}
                  href="#"
                  className="w-8 h-8 rounded-full bg-stone-200/50 text-stone-600 flex items-center justify-center hover:bg-amber-600/10 hover:text-amber-700 transition-all text-xs"
                >
                  {social[0]}
                </a>
              ))}
            </div>
          </div>

          {/* Quick Nav */}
          <div>
            <h3 className="text-sm font-semibold tracking-wider text-stone-900 uppercase mb-6 border-l-2 border-amber-600 pl-3">
              Explore Showroom
            </h3>
            <ul className="space-y-3 text-sm">
              {[
                { label: 'Premium Inventory', page: 'inventory' },
                { label: 'Bespoke Financing', page: 'finance' },
                { label: 'Exclusive Test Drives', page: 'testdrive' },
                { label: 'Precision Service Hub', page: 'service' },
                { label: 'Festive Privileges', page: 'offers' }
              ].map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => {
                      setActivePage(link.page as ActivePage);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="hover:text-amber-700 transition-colors flex items-center space-x-1 group"
                  >
                    <span>{link.label}</span>
                    <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Details */}
          <div>
            <h3 className="text-sm font-semibold tracking-wider text-stone-900 uppercase mb-6 border-l-2 border-amber-600 pl-3">
              Elite Support
            </h3>
            <ul className="space-y-4 text-sm">
              <li className="flex items-start space-x-3">
                <MapPin className="w-4 h-4 mt-1 text-amber-600 shrink-0" />
                <span className="text-stone-500">
                  Luxura Lucknow Showroom, Vibhuti Khand, Gomti Nagar, Lucknow, UP - 226010
                </span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-amber-600 shrink-0" />
                <span className="text-stone-600">+91 1800-419-8888</span>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-amber-600 shrink-0" />
                <span className="text-stone-600">concierge@luxuramotors.com</span>
              </li>
            </ul>
          </div>

          {/* Core Guarantees */}
          <div className="space-y-4 bg-white border border-stone-200/60 p-5 rounded-lg shadow-sm">
            <h3 className="text-sm font-semibold tracking-wider text-stone-900 uppercase mb-2 flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-amber-600" />
              <span>Luxura Assurance</span>
            </h3>
            <div className="text-xs text-stone-500 space-y-3 leading-relaxed">
              <p className="flex items-center space-x-2">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-600" />
                <span>Certified 120-Point Inspection</span>
              </p>
              <p className="flex items-center space-x-2">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-600" />
                <span>3-Year Elite Roadside Assist</span>
              </p>
              <p className="flex items-center space-x-2">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-600" />
                <span>Original OEM Spares Only</span>
              </p>
            </div>
            <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-500">
              <span className="flex items-center space-x-1">
                <HeartHandshake className="w-3.5 h-3.5 text-amber-600" />
                <span>Trusted Service</span>
              </span>
              <span className="text-amber-700 font-mono font-bold flex items-center space-x-1">
                <Star className="w-3 h-3 text-amber-600 fill-current" />
                <span>4.9/5</span>
              </span>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-stone-200/80 my-8 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-stone-400">
          <p>© {currentYear} Luxura Motors Ltd. All Rights Reserved. Crafted with precision for high-performance experiences.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-amber-700 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-amber-700 transition-colors">Terms of Use</a>
            <a href="#" className="hover:text-amber-700 transition-colors">Whistleblower Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
