export interface ColorOption {
  name: string;
  hex: string;
}

export interface Vehicle {
  id: string;
  brand: string;
  model: string;
  badge: string;
  type: string;
  lifestyle: 'SUV' | 'Sedan' | 'Electric' | 'Luxury' | 'CNG';
  fuel: 'Petrol' | 'Diesel' | 'Electric' | 'CNG';
  transmission: 'Automatic' | 'Manual';
  price: number; // in Lakhs
  emi: number; // monthly EMI in INR
  seats: number;
  engine: string;
  power: string;
  mileage: string; // or range for electric
  images: string[];
  colors: ColorOption[];
  description: string;
  features: string[];
  rating: number;
}

export type ActivePage = 'home' | 'inventory' | 'details' | 'finance' | 'tradein' | 'testdrive' | 'service' | 'offers';

export interface FinanceApplication {
  name: string;
  phone: string;
  whatsappUpdates: boolean;
  model: string;
  status: 'pending' | 'approved';
  id?: string;
}

export interface TradeInEstimation {
  brand: string;
  model: string;
  year: number;
  kms: number;
  condition: 'Excellent' | 'Good' | 'Fair';
}

export interface TestDriveBooking {
  id: string;
  modelId: string;
  modelName: string;
  date: string;
  time: string;
  name: string;
  phone: string;
  email: string;
  hasLicense: boolean;
  status: 'scheduled' | 'Cancelled';
  createdAt: string;
}

export interface ServiceBooking {
  id: string;
  name: string;
  phone: string;
  model: string;
  serviceType: string;
  date: string;
  status: 'Scheduled' | 'Cancelled';
}
